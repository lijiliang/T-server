var config = require('./config.json');

// 目录配置
config.path = {
    controller:  'controllers',
    view: "views"
};

config.sessionKey = 'm_ddd';

module.exports = config;