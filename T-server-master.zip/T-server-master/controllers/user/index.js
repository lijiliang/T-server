/*
 *  index
 */
module.exports = function* (){
    this.body = 'user index controller';
};
