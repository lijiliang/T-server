/*
 *  user
 */

module.exports = function* (){
    this.body = 'user other body';
};
